document.addEventListener("DOMContentLoaded", function() {

	// Custom JS

});
